export interface Emoji {
  emoji: string
  description: string
}

# Electron Emoji Picker

Trying to make a better experiance than the native macOS emoji picker. I find the native application for it very clunky and difficult to browse different categories and searching.

In my emoji picker I enable tab-navigation, fast and simple search, larger icons for better visibility.

Intended for personal use only! ... and only focusing on macOS since that's the only OS I have available.